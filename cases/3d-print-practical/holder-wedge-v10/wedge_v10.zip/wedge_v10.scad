// Toilet paper holder wedge V10 / equal 76mm screw pitches, mm.
// Photo coordinate convention: look at ANGLED/HOLDER side from front;
// white holder slots left and right, gold wall apertures center and right.
// Fixed WALL x positions (-6,+70), confirmed by user. Do NOT mirror these
// without checking the installation orientation on the actual wall.
// HOLDER bolt axes on inclined front, 76mm center-to-center in 3D,
// away from their uncertain outer margins. Long holes on this model are VERTICAL
// to retain height adjustment; horizontal adjustment comes from actual white slots.
// Wedge dimensions cover nut tracks at BOTH 10 and 15 degrees; same footprint.
// Printing: flat wall face at z=0 on print bed; no printed nut adapters.
angle_deg=10; // 10 or 15
wall_x=[-6,70];
holder_pitch=76; // true 3D center distance measured along sloping face
holder_mid=2; // same datum as v9; chosen near inner ends of real holder slots
holder_dx=holder_pitch*cos(angle_deg);
holder_x=[holder_mid-holder_dx/2,holder_mid+holder_dx/2];
body_left=-73;
body_right=85;
body_height=60;
min_thickness_at_right=10;
wall_shank_d=5.1;
wall_slot_y=20;
wall_head_recess_d=11.6;
wall_head_floor_z=3.8;
holder_bolt_d=5.6;
holder_slot_y=20;
front_skin_normal=5.0;
nut_cavity_x=13.3;
nut_cavity_y=31;
$fn=72;
// Front slope rises toward negative x: thick on left when looking at front.
function top_z(x)=min_thickness_at_right+(body_right-x)*tan(angle_deg);
module long_hole_z(d,y_length,z_start,z_length){
    hull(){
      translate([0,-(y_length-d)/2,z_start]) cylinder(d=d,h=z_length);
      translate([0, (y_length-d)/2,z_start]) cylinder(d=d,h=z_length);
    }
}
module shell(){
    hy=body_height/2;
    polyhedron(points=[
      [body_left,-hy,0],[body_right,-hy,0],[body_right,hy,0],[body_left,hy,0],
      [body_left,-hy,top_z(body_left)],[body_right,-hy,top_z(body_right)],
      [body_right,hy,top_z(body_right)],[body_left,hy,top_z(body_left)]
    ],faces=[[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]);
}
// WALL mounting screws: narrow wall-end shank and wider head access from the front.
module wall_clearance(){
  for(x=wall_x) translate([x,0,0]) {
    long_hole_z(wall_shank_d,wall_slot_y,-1,wall_head_floor_z+2);
    long_hole_z(wall_head_recess_d,wall_slot_y+wall_head_recess_d-wall_shank_d,
      wall_head_floor_z,top_z(body_left)+4);
  }
}
// HOLDER bolts: local z is normal to sloping face. Backside opens to nut recess.
// The -5mm roof is parallel to the sloping face. Wall holes unchanged.
module holder_clearance(){
  for(x=holder_x) translate([x,0,top_z(x)]) rotate([0,angle_deg,0]) {
    long_hole_z(holder_bolt_d,holder_slot_y,-front_skin_normal-0.1,front_skin_normal+2.1);
    translate([-nut_cavity_x/2,-nut_cavity_y/2,-100])
      cube([nut_cavity_x,nut_cavity_y,100-front_skin_normal]);
  }
}
difference(){shell();wall_clearance();holder_clearance();}
