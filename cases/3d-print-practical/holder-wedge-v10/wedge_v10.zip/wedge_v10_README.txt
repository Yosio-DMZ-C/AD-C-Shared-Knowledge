Wedge adapter v10 - 3D data only / Bambu Lab A1 mini

Files:
 wedge_v10_10.3mf / wedge_v10_15.3mf : Bambu Studio 3MF (unit mm)
 wedge_v10_10.stl / wedge_v10_15.stl : STL
 wedge_v10.scad : editable OpenSCAD (angle_deg=10 or 15)

CHANGES from v9:
 - Wall hole centers unchanged: x=-6 and +70 mm (pitch 76 mm).
 - Holder screw center distance now exactly 76 mm MEASURED ON THE TILTED FACE,
   for BOTH 10 and 15 degrees. (Projected X pitch changes with angle.)
 - Holder screw locations shifted closer to center, using the actual elongated
   holder slot ends for adjustment, rather than assumed 108mm bolt pitch.
 - Holder face skin 5 mm, no nut adapters, 158x60mm footprint unchanged.
 - All 4 slots on the same Y=0 center line, no vertical staggering.

IMPORTANT: physical fit and screw/nut sizes are not proven by the mesh tests.
 Match the back flat wall face to the actual wall; mount holder on tilted face.
 If the holder slots do not admit a 76mm bolt pitch, stop before printing.
 Printed part has not been opened in Bambu Studio during this build.
